#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>

// Function to convert a hex string to an integer (reading two characters at a time)
int hexStringToInt(const std::string& hexStr) {
    int value = 0;
    for (char c : hexStr) {
        value *= 16; // Shift current value by 4 bits
        if (isdigit(c)) {
            value += c - '0';
        } else if (isalpha(c)) {
            value += tolower(c) - 'a' + 10;
        }
    }
    return value;
}

// Function to convert a hex string to ASCII
std::string hexStringToASCII(const std::string& hexStr) {
    std::string result;
    for (size_t i = 0; i < hexStr.length(); i += 2) {
        std::string byteStr = hexStr.substr(i, 2); // Get two characters at a time
        int value = std::stoi(byteStr, nullptr, 16); // Convert hex string to integer
        result += static_cast<char>(value); // Convert integer to ASCII character
    }
    return result;
}


// Function to convert MIDI value to bipolar value
float midiToBipolar(int midiValue) {
    // Ensure the MIDI value is within the valid range (0 to 127)
    if (midiValue < 0) {
        midiValue = 0;
    } else if (midiValue > 127) {
        midiValue = 127;
    }

    // Calculate the bipolar value
    float bipolarValue = (midiValue - 64) / 64.0f * 64.0f;

    return bipolarValue;
}



int main() {

    std::ifstream inputFile("b067_steelWaveSound.txt");//, std::ios::binary);// for reading sys not working std::ios::binary); // Replace with your input file name
    std::ofstream outputFile("b067_steelWaveSound.xml"); // Replace with your output file name

    if (!inputFile || !outputFile) {
        std::cerr << "Failed to open files!" << std::endl;
        return 1;
    }
    // Put in a sound or bank checker here
        //if .snd name = filename
        //if .syx and length minus spaces is 532 then it's a sound dump
        //if .syx and longer is TBD a performance, arrangement or soundbank

    // Put in a header checker here
    // Read the SysEx message and skip the header (first 6 bytes)
    // weird number because of the spaces in the dump file.  come back and get rid of spaces and verify header please
    inputFile.seekg(19); // Seek past the header

    // Initialize variables to store the name portion
    std::vector<int> nameBytes;
    std::string name;

    // Create the root element
    outputFile << "<SynthPatch>" << std::endl;

    // Read the entire hexadecimal string
    std::string hexString;
    char hexChar;
    while (inputFile.get(hexChar)) {
        if (isxdigit(hexChar)) {
            hexString += hexChar;
        }
    }

// Remove all spaces from the hexString
    hexString.erase(std::remove_if(hexString.begin(), hexString.end(), ::isspace), hexString.end());

//remove footer  add verification later
    hexString.erase(hexString.length() - 4);


    // Process the cleaned hexString in pairs of two hex characters
    for (int i = 0; i < hexString.length(); i += 2) {
        std::string hexByte = hexString.substr(i, 2);

        // Handle name bytes (last 16 bytes)
        if (i >= 480 && i < 512) {
            name+=(hexStringToASCII(hexByte));
        // std::cout << name << std::endl;   // TS

        }

        // Convert the rest of the hex bytes to an integer
        if (i < 480) {
            int intValue = hexStringToInt(hexByte);





        //std::cout << hexByte[0] << hexByte[1] << " converted to " << intValue << std::endl; // For troubleshooting





        std::string paramName;



            // Define parameter names based on the provided index
            //// added chopper spots
            switch (i) {
                            //i should put limits on illegal values like bend range
                        case 0: paramName = "osc1_octave"; break;
                        case 2: paramName = "osc1_semitone"; break;
                        case 4: paramName = "osc1_detune"; intValue = midiToBipolar(intValue); break;
                        case 6: paramName = "osc1_bendrange";  intValue = midiToBipolar(intValue); break;
                        case 8: paramName = "osc1_pitchmode"; break;
                        case 10: paramName = "osc1_mod1_source"; break;
                        case 12: paramName = "osc1_mod1_control"; break;
                        case 14: paramName = "osc1_mod1_amt"; intValue = midiToBipolar(intValue);  break;
                        case 16: paramName = "osc1_mod2_source"; break;
                        case 18: paramName = "osc1_mod2_amount"; intValue = midiToBipolar(intValue);  break;
                        case 20: paramName = "osc1_mod2_quantize"; break;
                        case 22: paramName = "unused"; break;
                        case 24: paramName = "osc2_octave"; break;
                        case 26: paramName = "osc2_semitone"; break;
                        case 28: paramName = "osc2_detune"; intValue = midiToBipolar(intValue);  break;
                        case 30: paramName = "osc2_bendrange"; intValue = midiToBipolar(intValue);  break;
                        case 32: paramName = "osc2_pitchmode"; break;
                        case 34: paramName = "osc2_mod1_source"; break;
                        case 36: paramName = "osc2_mod1_control"; break;
                        case 38: paramName = "osc2_mod1_amt"; intValue = midiToBipolar(intValue);  break;
                        case 40: paramName = "osc2_mod2_source"; break;
                        case 42: paramName = "osc2_mod2_amount"; intValue = midiToBipolar(intValue);  break;
                        case 44: paramName = "osc2_mod2_quantize"; break;
                        case 46: paramName = "osc2_link"; break;
                        case 48: paramName = "unused"; break;
                        case 50: paramName = "wave1_wavetable"; break;
                        case 52: paramName = "wave1_wavepos"; break;
                        case 54: paramName = "wave1_phase"; break;
                        case 56: paramName = "wave1_startmod_source"; break;
                        case 58: paramName = "wave1_startmod_amount"; intValue = midiToBipolar(intValue); break;
                        case 60: paramName = "wave1_env_amt"; intValue = midiToBipolar(intValue);  break;
                        case 62: paramName = "wave1_env_velamt";  intValue = midiToBipolar(intValue); break;
                        case 64: paramName = "wave1_kbcenter"; break;
                        case 66: paramName = "wave1_kbtrack";  intValue = midiToBipolar(intValue); break;
                        case 68: paramName = "wave1_mod1_source"; break;
                        case 70: paramName = "wave1_mod1_control"; break;
                        case 72: paramName = "wave1_mod1_amount"; intValue = midiToBipolar(intValue);  break;
                        case 74: paramName = "wave1_mod2_source"; break;
                        case 76: paramName = "wave1_mod2_amount"; intValue = midiToBipolar(intValue);  break;
                        case 78: paramName = "wave1_mod2_quantize"; break;
                        case 80: paramName = "wave1_steppedsmooth"; break;
                        case 82: paramName = "unused"; break;
                        case 84: paramName = "wave2_startwave"; break;
                        case 86: paramName = "wave2_wavephase"; break;
                        case 88: paramName = "wave2_startmod_source"; break;
                        case 90: paramName = "wave2_startmod_amount"; intValue = midiToBipolar(intValue);  break;
                        case 92: paramName = "wave2_env_amount";  intValue = midiToBipolar(intValue); break;
                        case 94: paramName = "wave2_env_velamt"; intValue = midiToBipolar(intValue);  break;
                        case 96: paramName = "wave2_kbtrack";  intValue = midiToBipolar(intValue); break;
                        case 98: paramName = "wave2_kbcenter"; break;
                        case 100: paramName = "wave2_mod1_source"; break;
                        case 102: paramName = "wave2_mod1_control"; break;
                        case 104: paramName = "wave2_mod1_amount"; intValue = midiToBipolar(intValue);  break;
                        case 106: paramName = "wave2_mod2_source"; break;
                        case 108: paramName = "wave2_mod2_amount";  intValue = midiToBipolar(intValue); break;
                        case 110: paramName = "wave2_mod2_quantize"; break;
                        case 112: paramName = "wave2_steppedsmooth"; break;
                        case 114: paramName = "wave2_link"; break;
                        case 116: paramName = "unused"; break;
                        case 118: paramName = "wave1_vol"; break;
                        case 120: paramName = "wave2_vol"; break;
                        case 122: paramName = "noise_vol"; break;
                        case 124: paramName = "wave1_volmod_source"; break;
                        case 126: paramName = "wave1_volmod_amount"; intValue = midiToBipolar(intValue);  break;
                        case 128: paramName = "wave2_volmod_source"; break;
                        case 130: paramName = "wave2_volmod_amount"; intValue = midiToBipolar(intValue);  break;
                        case 132: paramName = "noise_volmod_source"; break;
                        case 134: paramName = "noise_volmod_amount"; intValue = midiToBipolar(intValue);  break;
                        case 136: paramName = "amp_env_amt"; intValue = midiToBipolar(intValue);  break;
                        case 138: paramName = "amp_env_velamt";intValue = midiToBipolar(intValue);  break; break;
                        case 140: paramName = "amp_kbcenter"; break;
                        case 142: paramName = "amp_kbtrack"; break;
                        case 144: paramName = "amp_mod1_source"; break;
                        case 146: paramName = "amp_mod1_control"; break;
                        case 148: paramName = "amp_mod1_amount"; break;
                        case 150: paramName = "amp_mod2_source"; break;
                        case 152: paramName = "amp_mod2_amount"; break;
                        case 154: paramName = "unused"; break;
                        case 156: paramName = "filter_mode"; break;
                        case 158: paramName = "filter_lp_freq"; break;
                        case 160: paramName = "filter_resonance"; break;
                        case 162: paramName = "filter_env_amt"; intValue = midiToBipolar(intValue);  break;
                        case 164: paramName = "filter_velocity";  intValue = midiToBipolar(intValue); break;
                        case 166: paramName = "filter_keytrack"; intValue = midiToBipolar(intValue);  break;
                        case 168: paramName = "filter_keycenter"; break;
                        case 170: paramName = "filter_mod1_source"; break;
                        case 172: paramName = "filter_mod1_control"; break;
                        case 174: paramName = "filter_mod1_amount";  intValue = midiToBipolar(intValue); break;
                        case 176: paramName = "filter_mod2_source"; break;
                        case 178: paramName = "filter_mod2_amount";  intValue = midiToBipolar(intValue); break;
                        case 180: paramName = "filter_resmod_source"; break;
                        case 182: paramName = "filter_resmod_control"; break;
                        case 184: paramName = "filter_resmod_amount";  intValue = midiToBipolar(intValue); break;
                        case 186: paramName = "dualmode_hp_freq"; break;
                        case 188: paramName = "dualmode_hp_env_select"; break;
                        case 190: paramName = "dualmode_hp_env_amt";intValue = midiToBipolar(intValue);   break;
                        case 192: paramName = "dualmode_hp_vel_amt"; intValue = midiToBipolar(intValue);  break;
                        case 194: paramName = "dualmode_hp_keytrack"; break;
                        case 196: paramName = "dualmode_hp_keycenter"; break;
                        case 198: paramName = "dualmode_hp_mod1_source"; break;
                        case 200: paramName = "dualmode_hp_mod1_control"; break;
                        case 202: paramName = "dualmode_hp_mod1_amt";intValue = midiToBipolar(intValue);  break;
                        case 204: paramName = "dualmode_hp_mod2_source"; break;
                        case 206: paramName = "dualmode_hp_mod2_amount"; break;
                        case 208: paramName = "bandpass_filter_bandwidth"; break;
                        case 210: paramName = "unused"; break;
                        case 212: paramName = "amp_env_attack"; break;
                        case 214: paramName = "amp_env_decay"; break;
                        case 216: paramName = "amp_env_sustain"; break;
                        case 218: paramName = "amp_env_release"; break;
                        case 220: paramName = "amp_env_attack_mod_source"; break;
                        case 222: paramName = "amp_env_attack_mod_amount"; intValue = midiToBipolar(intValue);  break;
                        case 224: paramName = "amp_env_decay_mod_source"; break;
                        case 226: paramName = "amp_env_decay_mod_amount"; intValue = midiToBipolar(intValue);  break;
                        case 228: paramName = "amp_env_sustain_mod_source"; break;
                        case 230: paramName = "amp_env_sustain_mod_amount";  intValue = midiToBipolar(intValue); break;
                        case 232: paramName = "amp_env_release_mod_source"; break;
                        case 234: paramName = "amp_env_release_mod_amount"; intValue = midiToBipolar(intValue);  break;
                        case 236: paramName = "unused"; break;
                        case 238: paramName = "filter_env_delay"; break;
                        case 240: paramName = "filter_env_attack"; break;
                        case 242: paramName = "filter_env_decay"; break;
                        case 244: paramName = "filter_env_sustain"; break;
                        case 246: paramName = "filter_env_release"; break;
                        case 248: paramName = "unused"; break;
                        case 250: paramName = "unused"; break;
                        case 252: paramName = "filter_env_attack_mod_source"; break;
                        case 254: paramName = "filter_env_attack_mod_amount"; intValue = midiToBipolar(intValue);  break;
                        case 256: paramName = "filter_env_decay_mod_source"; break;
                        case 258: paramName = "filter_env_decay_mod_amount"; intValue = midiToBipolar(intValue);  break;
                        case 260: paramName = "filter_env_sustain_mod_source"; break;
                        case 262: paramName = "filter_env_sustain_mod_amount"; intValue = midiToBipolar(intValue);  break;
                        case 264: paramName = "filter_env_release_mod_source"; break;
                        case 266: paramName = "filter_env_release_mod_amount";  intValue = midiToBipolar(intValue); break;
                        case 268: paramName = "unused"; break;
                        case 270: paramName = "wave_env_time1"; break;
                        case 272: paramName = "wave_env_level1"; break;
                        case 274: paramName = "wave_env_time2"; break;
                        case 276: paramName = "wave_env_level2"; break;
                        case 278: paramName = "wave_env_time3"; break;
                        case 280: paramName = "wave_env_level3"; break;
                        case 282: paramName = "wave_env_time4"; break;
                        case 284: paramName = "wave_env_level4"; break;
                        case 286: paramName = "wave_env_time5"; break;
                        case 288: paramName = "wave_env_level5"; break;
                        case 290: paramName = "wave_env_time6"; break;
                        case 292: paramName = "wave_env_level6"; break;
                        case 294: paramName = "wave_env_time7"; break;
                        case 296: paramName = "wave_env_level7"; break;
                        case 298: paramName = "wave_env_time8"; break;
                        case 300: paramName = "wave_env_level8"; break;
                        case 302: paramName = "wave_env_timemod_source"; break;
                        case 304: paramName = "wave_env_timemod_amount"; intValue = midiToBipolar(intValue);  break;
                        case 306: paramName = "wave_env_levelmod_source"; break;
                        case 308: paramName = "wave_env_levelmod_amount"; intValue = midiToBipolar(intValue);  break;
                        case 310: paramName = "wave_env_keyoffpoint"; break;
                        case 312: paramName = "wave_env_loopstartpoint"; break;
                        case 314: paramName = "wave_env_looponoff"; break;
                        case 316: paramName = "unused"; break;
                        case 318: paramName = "free_env_time1"; break;
                        case 320: paramName = "free_env_level1"; break;
                        case 322: paramName = "free_env_time2"; break;
                        case 324: paramName = "free_env_level2"; break;
                        case 326: paramName = "free_env_time3"; break;
                        case 328: paramName = "free_env_level3"; break;
                        case 330: paramName = "free_env_time4"; break;
                        case 332: paramName = "free_env_level4"; break;
                        case 334: paramName = "free_env_timemod_source"; break;
                        case 336: paramName = "free_env_timemod_amount";  intValue = midiToBipolar(intValue); break;
                        case 338: paramName = "free_env_levelmod_source"; break;
                        case 340: paramName = "free_env_levelmod_amount"; intValue = midiToBipolar(intValue);  break;
                        case 342: paramName = "free_env_zeroaxis"; break;
                        case 344: paramName = "lfo1_rate"; break;
                        case 346: paramName = "lfo1_shape"; break;
                        case 348: paramName = "lfo1_symmetry"; break;
                        case 350: paramName = "lfo1_humanize"; break;
                        case 352: paramName = "lfo1_rate_mod_source"; break;
                        case 354: paramName = "lfo1_rate_mod_amount"; break;
                        case 356: paramName = "lfo1_level_mod_source"; break;
                        case 358: paramName = "lfo1_level_mod_control"; break;
                        case 360: paramName = "lfo1_level_mod_amount"; break;
                        case 362: paramName = "lfo1_sync"; break;
                        case 364: paramName = "lfo2_rate"; break;
                        case 366: paramName = "lfo2_shape"; break;
                        case 368: paramName = "lfo2_symmetry"; break;
                        case 370: paramName = "lfo2_humanize"; break;
                        case 372: paramName = "lfo2_rate_mod"; break;
                        case 374: paramName = "lfo2_rate_mod"; break;
                        case 376: paramName = "lfo2_level_mod_source"; break;
                        case 378: paramName = "lfo2_level_mod_control"; break;
                        case 380: paramName = "lfo2_level_mod_amount"; break;
                        case 382: paramName = "lfo2_sync"; break;
                        case 384: paramName = "control_ramp_trigger_source"; break;
                        case 386: paramName = "control_ramp_rate"; intValue = midiToBipolar(intValue);  break;
                        case 388: paramName = "panning_source1"; break;
                        case 390: paramName = "panning_control1"; break;
                        case 392: paramName = "panning_amount1"; intValue = midiToBipolar(intValue);  break;
                        case 394: paramName = "panning_source2"; break;
                        case 396: paramName = "panning_amount2"; intValue = midiToBipolar(intValue); break;
                        case 398: paramName = "control_comparator_source"; break;
                        case 400: paramName = "control_comparator_threshold"; intValue = midiToBipolar(intValue);  break;
                        case 402: paramName = "control_mixer_source1"; break;
                        case 404: paramName = "control_mixer_amount1"; intValue = midiToBipolar(intValue);  break;
                        case 406: paramName = "control_mixer_source2"; break;
                        case 408: paramName = "control_mixer_amount2";  intValue = midiToBipolar(intValue); break;
                        case 410: paramName = "control_mixer_source3"; break;
                        case 412: paramName = "control_mixer_amount3";  intValue = midiToBipolar(intValue); break;
                        case 414: paramName = "control_delay_source"; break;
                        case 416: paramName = "control_delay_time"; break;
                        case 418: paramName = "control_delay_t_mod_source"; break;
                        case 420: paramName = "control_delay_t_mod_amount"; intValue = midiToBipolar(intValue);  break;
                        case 422: paramName = "control_shaper_source"; break;
                        case 424: paramName = "control_shaper_refpoint1"; break;
                        case 426: paramName = "control_shaper_refpoint2"; break;
                        case 428: paramName = "control_shaper_refpoint3"; break;
                        case 430: paramName = "control_shaper_refpoint4"; break;
                        case 432: paramName = "control_shaper_refpoint5"; break;
                        case 434: paramName = "control_shaper_refpoint6"; break;
                        case 436: paramName = "control_shaper_refpoint7"; break;
                        case 438: paramName = "control_shaper_refpoint8"; break;
                        case 440: paramName = "control_shaper_refpoint9"; break;
                        case 442: paramName = "sample_hold_source"; break;
                        case 444: paramName = "sample_hold_rate"; break;
                        case 446: paramName = "sample_hold_rate_mod_source"; break;
                        case 448: paramName = "sample_hold_rate_mod_amount"; intValue = midiToBipolar(intValue);  break;
                        case 450: paramName = "unused"; break;
                        case 452: paramName = "aux_level_mod_source"; break;
                        case 454: paramName = "aux_level_mod_control"; break;
                        case 456: paramName = "aux_level_mod_amount"; intValue = midiToBipolar(intValue) ; break;
                        case 458: paramName = "aux_level_min"; break;
                        case 460: paramName = "unused"; break;
                        case 462: paramName = "unused"; break;
                        case 464: paramName = "unused"; break;
                        case 466: paramName = "glide_mode"; break;
                        case 468: paramName = "glide_rate"; break;
                        case 470: paramName = "glide_slope"; break;
                        case 472: paramName = "glide_time_mod_source"; break;
                        case 474: paramName = "glide_time_mod_amount"; break;
                        case 476: paramName = "glide_onoff"; break;
                        case 478: paramName = "valid_flag"; break;






                    default: paramName = "Parameter" + std::to_string(i / 2); break;
            }

            double paramValue = static_cast<double>(intValue);

            // Write the parameter to the XML file
            outputFile << "  <Parameter name=\"" << paramName << "\" value=\"" << paramValue << "\"/>" << std::endl;
}
    }




//// Convert the name bytes to ASCII and write to the XML  DOESNT WORK YET


    std::cout<< name << std::endl;
    outputFile << "  <Parameter name=\"Name\" value=\"" << name << "\"/>" << std::endl;


    // Close the root element
    outputFile << "</SynthPatch>" << std::endl;

    // Close the input and output files
    inputFile.close();
    outputFile.close();

    std::cout << "Conversion complete!" << std::endl;

    return 0;
}
